#include <iostream>
#include <string>
using namespace std;

class vehicle {
protected:
    string brand;
    string model;
    int year;
    double price;

public:
    vehicle(string b, string m, int y, double p) {
        brand = b;
        model = m;
        year = y;
        price = p;
    }

    virtual void displayinfo() {
        cout << "\n[Vehicle Details]";
        cout << "\nBrand: " << brand;
        cout << "\nModel: " << model;
        cout << "\nReleased in: " << year;
        cout << "\nPrice: $" << price;
    }

    virtual void startengine(int cc) {
        cout << "\nEngine capacity: " << cc << " cc";
    }

    virtual void calcalute_depresiation_year(int cost, int salvage, int life) {
        int depreciation = (cost - salvage) / life;
        cout << "\nYearly depreciation: " << depreciation;
    }
};

class car : public vehicle {
protected:
    int doors;
    string fueltype;

public:
    car(string b, string m, int y, double p, int d, string ft)
        : vehicle(b, m, y, p) 
    {
        doors = d;
        fueltype = ft;
    }

    void opentruck(int size) {
        cout << "\nTrunk opening size: " << size << " ft";
    }

    void music(int volume) {
        cout << "\nMusic system volume set to: " << volume;
    }

    void displayinfo() override {
        cout << "\n[Car Details]";
        cout << "\nDoors: " << doors;
        cout << "\nFuel Type: " << fueltype;
    }
};

class motorcycle : public vehicle {
protected:
    string type;
    bool hasHelmet;

public:
    motorcycle(string b, string m, int y, double p, string t, bool h)
        : vehicle(b, m, y, p) 
    {
        type = t;
        hasHelmet = h;
    }

    void doWheelie() {
        cout << "\nMotorcycle performs a wheelie!";
    }

    void calcalute_depresiation_year(int cost, int salvage, int life) override {
        int val = (cost - salvage) / life;
        cout << "\nMotorcycle depreciation per year: " << val;
    }

    void displayinfo() override {
        cout << "\n[Motorcycle Details]";
        cout << "\nType: " << type;
        cout << "\nHelmet Included: " << (hasHelmet ? "Yes" : "No");
    }
};

class truck : public vehicle {
protected:
    double capacity;
    int axles;

public:
    truck(string b, string m, int y, double p, double c, int ax)
        : vehicle(b, m, y, p) 
    {
        capacity = c;
        axles = ax;
    }

    void loadCargo() {
        cout << "\nTruck is being loaded with cargo...";
    }

    void unloadCargo() {
        cout << "\nCargo unloading in progress...";
    }

    void displayinfo() override {
        cout << "\n[Truck Details]";
        cout << "\nLoad Capacity: " << capacity << " tons";
        cout << "\nNumber of Axles: " << axles;
    }
};

class VehicleShowroom {
protected:
    vehicle* list[10];
    int count;

public:
    VehicleShowroom() {
        count = 0;
    }

    void addVehicle(vehicle* v) {
        if (count < 10) {
            list[count] = v;
            count++;
        } else {
            cout << "\nShowroom is full! Cannot add more vehicles.";
        }
    }

    void showAllVehicles() {
        cout << "\n\n--- Displaying All Vehicles in Showroom ---";
        for (int i = 0; i < count; i++) {
            cout << "\n\nVehicle " << i + 1 << ":";
            list[i]->displayinfo();
        }
    }
};

int main() {
    VehicleShowroom showroom;

    car c1("Toyota", "XLI", 2010, 24500, 4, "CNG");
    motorcycle m1("Honda", "125", 2020, 155000, "Sports", true);
    truck t1("Hino", "H07D", 2015, 4500000, 15.5, 4);

    showroom.addVehicle(&c1);
    showroom.addVehicle(&m1);
    showroom.addVehicle(&t1);

    showroom.showAllVehicles();

    return 0;
}
