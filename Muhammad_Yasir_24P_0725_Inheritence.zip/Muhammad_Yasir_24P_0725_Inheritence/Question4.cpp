#include <iostream>
using namespace std;

class ComplexNum {
protected:
    double realPart;
    double imagPart;

public:
    ComplexNum(double r = 0, double i = 0) {
        realPart = r;
        imagPart = i;
    }

    double magnitudeSquare() {
        return realPart * realPart + imagPart * imagPart;
    }

    ComplexNum makeConjugate() {
        return ComplexNum(realPart, -imagPart);
    }

    ComplexNum operator+(ComplexNum c) {
        return ComplexNum(realPart + c.realPart, imagPart + c.imagPart);
    }

    ComplexNum operator-(ComplexNum c) {
        return ComplexNum(realPart - c.realPart, imagPart - c.imagPart);
    }

    ComplexNum operator*(ComplexNum c) {
        double r = realPart * c.realPart - imagPart * c.imagPart;
        double i = realPart * c.imagPart + imagPart * c.realPart;
        return ComplexNum(r, i);
    }

    ComplexNum operator/(ComplexNum c) {
        double d = c.realPart * c.realPart + c.imagPart * c.imagPart;
        double r = (realPart * c.realPart + imagPart * c.imagPart) / d;
        double i = (imagPart * c.realPart - realPart * c.imagPart) / d;
        return ComplexNum(r, i);
    }

    bool operator==(ComplexNum c) {
        return realPart == c.realPart && imagPart == c.imagPart;
    }

    bool operator!=(ComplexNum c) {
        return !(*this == c);
    }

    bool operator<(ComplexNum c) {
        return magnitudeSquare() < c.magnitudeSquare();
    }

    bool operator>(ComplexNum c) {
        return magnitudeSquare() > c.magnitudeSquare();
    }

    ComplexNum operator+() { return *this; }

    ComplexNum operator-() { return ComplexNum(-realPart, -imagPart); }

    ComplexNum operator!() { return makeConjugate(); }

    ComplexNum& operator+=(ComplexNum c) {
        realPart += c.realPart;
        imagPart += c.imagPart;
        return *this;
    }

    ComplexNum& operator-=(ComplexNum c) {
        realPart -= c.realPart;
        imagPart -= c.imagPart;
        return *this;
    }

    ComplexNum& operator*=(ComplexNum c) {
        double r = realPart * c.realPart - imagPart * c.imagPart;
        double i = realPart * c.imagPart + imagPart * c.realPart;
        realPart = r;
        imagPart = i;
        return *this;
    }

    ComplexNum& operator/=(ComplexNum c) {
        double d = c.realPart * c.realPart + c.imagPart * c.imagPart;
        double r = (realPart * c.realPart + imagPart * c.imagPart) / d;
        double i = (imagPart * c.realPart - realPart * c.imagPart) / d;
        realPart = r;
        imagPart = i;
        return *this;
    }

    friend ostream& operator<<(ostream &out, ComplexNum c) {
        if (c.imagPart >= 0)
            out << c.realPart << " + " << c.imagPart << "i";
        else
            out << c.realPart << " - " << -c.imagPart << "i";
        return out;
    }

    friend istream& operator>>(istream &in, ComplexNum &c) {
        cout << "\nEnter real value: ";
        in >> c.realPart;
        cout << "Enter imaginary value: ";
        in >> c.imagPart;
        return in;
    }
};

int main() {
    ComplexNum a(3, 4), b(1, -2), result;

    cout << "\nFirst Number: " << a;
    cout << "\nSecond Number: " << b;

    result = a + b;
    cout << "\nSum: " << result;

    result = a - b;
    cout << "\nDifference: " << result;

    result = a * b;
    cout << "\nMultiplication: " << result;

    result = a / b;
    cout << "\nDivision: " << result;

    cout << "\nMagnitude squared of first: " << a.magnitudeSquare();

    cout << "\nConjugate of first: " << !a;

    result = -a;
    cout << "\nNegated form: " << result;

    a += b;
    cout << "\nAfter a += b: " << a;

    a -= b;
    cout << "\nAfter a -= b: " << a;

    a *= b;
    cout << "\nAfter a *= b: " << a;

    a /= b;
    cout << "\nAfter a /= b: " << a;

    return 0;
}
