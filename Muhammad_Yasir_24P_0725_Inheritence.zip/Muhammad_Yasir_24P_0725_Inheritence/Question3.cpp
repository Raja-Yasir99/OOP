#include <iostream>
#include <string>
using namespace std;

class employee {
protected:
    string empName;
    int empID;
    string dept;
    string joiningDate;

public:
    employee(string n, int i, string d, string j) {
        empName = n;
        empID = i;
        dept = d;
        joiningDate = j;
    }

    virtual double calculateSalary() = 0;

    virtual void displayInfo() {
        cout << "\nEmployee Name: " << empName
             << "\nID: " << empID
             << "\nDepartment: " << dept
             << "\nJoined on: " << joiningDate;
    }

    virtual void giveRaise(double percent) {
        cout << "\nApplying a " << percent << "% raise to " << empName;
    }

    virtual void performanceEvaluation() {
        cout << "\nEvaluating performance for " << empName;
    }

    string getName() {
        return empName;
    }

    string getDepartment() {
        return dept;
    }
};

class fulltimeemployee : public employee {
protected:
    double monthlySalary;
    double allowance;

public:
    fulltimeemployee(string n, int i, string d, string j, double sal, double all)
        : employee(n, i, d, j) {
        monthlySalary = sal;
        allowance = all;
    }

    double calculateSalary() {
        return monthlySalary + allowance;
    }

    void giveRaise(double percent) {
        monthlySalary = monthlySalary + (monthlySalary * percent / 100);
    }

    void performanceEvaluation() {
        cout << "\nFull-time employee " << empName << ": Performance is satisfactory.";
    }

    void displayInfo() {
        cout << "\n[Full-time Employee]"
             << "\nName: " << empName
             << "\nID: " << empID
             << "\nDepartment: " << dept
             << "\nJoined: " << joiningDate
             << "\nBase Salary: " << monthlySalary
             << "\nAllowances: " << allowance;
    }
};

class parttimeemployee : public employee {
protected:
    double payRate;
    double totalHours;

public:
    parttimeemployee(string n, int i, string d, string j, double r, double h)
        : employee(n, i, d, j) {
        payRate = r;
        totalHours = h;
    }

    double calculateSalary() {
        return payRate * totalHours;
    }

    void giveRaise(double percent) {
        payRate = payRate + (payRate * percent / 100);
    }

    void performanceEvaluation() {
        cout << "\nPart-time employee " << empName << ": Performance is acceptable.";
    }

    void displayInfo() {
        cout << "\n[Part-time Employee]"
             << "\nName: " << empName
             << "\nID: " << empID
             << "\nDepartment: " << dept
             << "\nJoined: " << joiningDate
             << "\nHourly Rate: " << payRate
             << "\nHours Worked: " << totalHours;
    }
};

class contractemployee : public employee {
protected:
    double contractPay;

public:
    contractemployee(string n, int i, string d, string j, double amount)
        : employee(n, i, d, j) {
        contractPay = amount;
    }

    double calculateSalary() {
        return contractPay;
    }

    void giveRaise(double percent) {
        contractPay = contractPay + (contractPay * percent / 100);
    }

    void performanceEvaluation() {
        cout << "\nContract employee " << empName << ": Excellent performance.";
    }

    void displayInfo() {
        cout << "\n[Contract Employee]"
             << "\nName: " << empName
             << "\nID: " << empID
             << "\nDepartment: " << dept
             << "\nJoined: " << joiningDate
             << "\nContract Amount: " << contractPay;
    }
};

class intern : public employee {
protected:
    double stipend;

public:
    intern(string n, int i, string d, string j, double s)
        : employee(n, i, d, j) {
        stipend = s;
    }

    double calculateSalary() {
        return stipend;
    }

    void giveRaise(double percent) {
        stipend = stipend + (stipend * percent / 100);
    }

    void performanceEvaluation() {
        cout << "\nIntern " << empName << ": Needs improvement.";
    }

    void displayInfo() {
        cout << "\n[Intern]"
             << "\nName: " << empName
             << "\nID: " << empID
             << "\nDepartment: " << dept
             << "\nJoined: " << joiningDate
             << "\nMonthly Stipend: " << stipend;
    }
};

class hrSystem {
protected:
    employee* empList[100];
    int empCount;

public:
    hrSystem() {
        empCount = 0;
    }

    void addEmployee(employee* e) {
        empList[empCount] = e;
        empCount++;
    }

    void showAllEmployees() {
        for (int i = 0; i < empCount; i++) {
            cout << "\n------------------------------";
            empList[i]->displayInfo();
            cout << "\nCalculated Salary: " << empList[i]->calculateSalary();
            empList[i]->performanceEvaluation();
        }
    }

    double totalPayroll() {
        double sum = 0;
        for (int i = 0; i < empCount; i++) {
            sum += empList[i]->calculateSalary();
        }
        return sum;
    }

    void searchByDepartment(string d) {
        cout << "\n\n--- Employees in Department: " << d << " ---";
        for (int i = 0; i < empCount; i++) {
            if (empList[i]->getDepartment() == d) {
                empList[i]->displayInfo();
                cout << "\nSalary: " << empList[i]->calculateSalary();
            }
        }
    }

    void searchByName(string n) {
        cout << "\n\n--- Searching for Employee: " << n << " ---";
        for (int i = 0; i < empCount; i++) {
            if (empList[i]->getName() == n) {
                empList[i]->displayInfo();
                cout << "\nSalary: " << empList[i]->calculateSalary();
            }
        }
    }
};

int main() {
    hrSystem hr;

    fulltimeemployee f1("John", 101, "IT", "2020-01-01", 5000, 900);
    parttimeemployee p1("Anna", 102, "HR", "2021-06-15", 18, 75);
    contractemployee c1("Mike", 103, "Finance", "2022-03-10", 3500);
    intern i1("Lisa", 104, "IT", "2023-07-01", 1200);

    hr.addEmployee(&f1);
    hr.addEmployee(&p1);
    hr.addEmployee(&c1);
    hr.addEmployee(&i1);

    hr.showAllEmployees();

    cout << "\n\nTotal Payroll Cost: " << hr.totalPayroll();

    hr.searchByDepartment("IT");
    hr.searchByName("Anna");

    return 0;
}
