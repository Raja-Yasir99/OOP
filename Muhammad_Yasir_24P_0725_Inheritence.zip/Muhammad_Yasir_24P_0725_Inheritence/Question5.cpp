#include <iostream>
#include <string>
using namespace std;

class Device {
protected:
    string deviceName;
    bool powerState;
public:
    Device(string n) {
        deviceName = n;
        powerState = false;
    }
    virtual void turnOn() {
        powerState = true;
        cout << "\n" << deviceName << " is now ON";
    }
    virtual void turnOff() {
        powerState = false;
        cout << "\n" << deviceName << " is now OFF";
    }
    virtual void showStatus() {
        cout << "\nStatus of " << deviceName << ": " << (powerState ? "ON" : "OFF");
    }
};

class Networked {
protected:
    string ip;
    int portNumber;
public:
    Networked(string address = "", int p = 0) {
        ip = address;
        portNumber = p;
    }
    virtual void connect() {
        cout << "\nConnecting to " << ip << " at port " << portNumber;
    }
    virtual void disconnect() {
        cout << "\nDisconnecting from " << ip << " at port " << portNumber;
    }
};

class Scheduled {
protected:
    string timing;
public:
    Scheduled(string s = "") {
        timing = s;
    }
    virtual void setSchedule(string s) {
        timing = s;
        cout << "\nSchedule updated: " << timing;
    }
    virtual void checkSchedule() {
        cout << "\nCurrent schedule: " << timing;
    }
};

class Securable {
protected:
    string passKey;
    int level;
public:
    Securable(string p = "", int l = 0) {
        passKey = p;
        level = l;
    }

    virtual bool authenticate(string input) {
        if (input == passKey) {
            cout << "\nAccess Granted!";
            return true;
        } else {
            cout << "\nAccess Denied!";
            return false;
        }
    }

    virtual void encrypt() {
        cout << "\nData locked using security level " << level;
    }
};

class SmartLight : public Device, public Networked, public Scheduled {
protected:
    int lightLevel;
public:
    SmartLight(string n, string ip, int p) : Device(n), Networked(ip, p) {
        lightLevel = 0;
    }
    void setBrightness(int b) {
        lightLevel = b;
        cout << "\nBrightness of " << deviceName << " set to " << lightLevel;
    }
    void showStatus() {
        cout << "\n" << deviceName << " is " << (powerState ? "ON" : "OFF");
        cout << "\nBrightness level: " << lightLevel;
    }
};

class SmartThermostat : public Device, public Networked, public Scheduled {
protected:
    double temp;
public:
    SmartThermostat(string n, string ip, int p) : Device(n), Networked(ip, p) {
        temp = 20.0;
    }

    void setTemperature(double t) {
        temp = t;
        cout << "\nTemperature for " << deviceName << " set to " << temp;
    }
    void showStatus() {
        cout << "\n" << deviceName << " is " << (powerState ? "ON" : "OFF");
        cout << "\nCurrent temperature: " << temp;
    }
};

class SecurityCamera : public Device, public Networked, public Securable {
protected:
    bool isRecording;
public:
    SecurityCamera(string n, string ip, int p, string pass, int lvl) :
        Device(n), Networked(ip, p), Securable(pass, lvl) {
        isRecording = false;
    }

    void startRecording() {
        if (powerState) {
            isRecording = true;
            cout << "\n" << deviceName << " has started recording.";
        } else {
            cout << "\nCannot record. " << deviceName << " is OFF.";
        }
    }

    void stopRecording() {
        isRecording = false;
        cout << "\nRecording stopped for " << deviceName;
    }

    void showStatus() {
        cout << "\n" << deviceName << " is " << (powerState ? "ON" : "OFF");
        cout << "\nRecording: " << (isRecording ? "ACTIVE" : "INACTIVE");
    }
};

class SmartDoor : public Device, public Networked, public Securable, public Scheduled {
protected:
    bool locked;
public:
    SmartDoor(string n, string ip, int p, string pass, int lvl) :
        Device(n), Networked(ip, p), Securable(pass, lvl) {
        locked = true;
    }

    void lockDoor() {
        locked = true;
        cout << "\n" << deviceName << " has been LOCKED";
    }

    void unlockDoor() {
        locked = false;
        cout << "\n" << deviceName << " has been UNLOCKED";
    }

    void showStatus() {
        cout << "\n" << deviceName << " is " << (powerState ? "ON" : "OFF");
        cout << "\nDoor Lock: " << (locked ? "LOCKED" : "UNLOCKED");
    }
};

int main() {
    SmartLight l1("Living Room Light", "192.168.1.2", 8080);
    SmartThermostat t1("Hall Thermostat", "192.168.1.3", 8081);
    SecurityCamera c1("Front Camera", "192.168.1.4", 8082, "1234", 5);
    SmartDoor d1("Main Door", "192.168.1.5", 8083, "abcd", 3);

    l1.turnOn();
    l1.setBrightness(75);
    l1.connect();
    l1.setSchedule("Turn ON at 7:00 AM | Turn OFF at 10:00 PM");
    l1.showStatus();

    t1.turnOn();
    t1.setTemperature(22.5);
    t1.connect();
    t1.setSchedule("Turn ON at 6:00 AM | Turn OFF at 11:00 PM");
    t1.showStatus();

    c1.turnOn();
    c1.connect();
    c1.authenticate("1234");
    c1.startRecording();
    c1.showStatus();

    d1.turnOn();
    d1.connect();
    d1.authenticate("abcd");
    d1.unlockDoor();
    d1.setSchedule("Unlock 7:00 AM | Lock 10:00 PM");
    d1.showStatus();

    return 0;
}
