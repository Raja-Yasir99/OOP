#include <iostream>
#include <string>
using namespace std;

class shape {
protected:
    string color;
    string name;

public:
    shape(string c, string n) {
        color = c;
        name = n;
    }

    virtual double area() = 0;
    virtual double perimeter() = 0;

    virtual void draw() {
        cout << "\nDrawing " << name << "...";
    }

    virtual void getDetails() {
        cout << "\nShape Name: " << name
             << " | Color: " << color;
    }
};

class circle : public shape {
protected:
    double radius;

public:
    circle(string c, string n, double r) : shape(c, n) {
        radius = (r > 0) ? r : 1;
    }

    double area() {
        return 3.14159 * radius * radius;
    }

    double perimeter() {
        return 2 * 3.14159 * radius;
    }

    void draw() {
        cout << "\n   ***\n *     *\n   ***   (Circle)";
    }

    void getDetails() {
        cout << "\nCircle: " << name
             << " | Color: " << color
             << " | Radius: " << radius;
    }
};

class rectangle : public shape {
protected:
    double width;
    double height;

public:
    rectangle(string c, string n, double w, double h) : shape(c, n) {
        width = (w > 0) ? w : 1;
        height = (h > 0) ? h : 1;
    }

    double area() {
        return width * height;
    }

    double perimeter() {
        return 2 * (width + height);
    }

    void draw() {
        cout << "\n ******\n *    *\n ******   (Rectangle)";
    }

    void getDetails() {
        cout << "\nRectangle: " << name
             << " | Color: " << color
             << " | Width: " << width
             << " | Height: " << height;
    }
};

class triangle : public shape {
protected:
    double a, b, c;

public:
    triangle(string c, string n, double x, double y, double z) : shape(c, n) {
        a = (x > 0) ? x : 1;
        b = (y > 0) ? y : 1;
        c = (z > 0) ? z : 1;
    }

    double area() {
        double s = (a + b + c) / 2;
        double calc = s * (s - a) * (s - b) * (s - c);
        return (calc < 0 ? 0 : calc);
    }

    double perimeter() {
        return a + b + c;
    }

    void draw() {
        cout << "\n   *   \n  * *  \n *****   (Triangle)";
    }

    void getDetails() {
        cout << "\nTriangle: " << name
             << " | Color: " << color
             << " | Sides: " << a << ", " << b << ", " << c;
    }
};

class pentagon : public shape {
protected:
    double side;

public:
    pentagon(string c, string n, double s) : shape(c, n) {
        side = (s > 0) ? s : 1;
    }

    double area() {
        return (5 * side * side) / 4;
    }

    double perimeter() {
        return 5 * side;
    }

    void draw() {
        cout << "\n   *   \n *   *\n*******   (Pentagon)";
    }

    void getDetails() {
        cout << "\nPentagon: " << name
             << " | Color: " << color
             << " | Side Length: " << side;
    }
};

class shapemanager {
protected:
    shape* list[100];
    int count;

public:
    shapemanager() {
        count = 0;
    }

    void addShape(shape* s) {
        if (count < 100) {
            list[count++] = s;
        }
    }

    void showAllShapes() {
        for (int i = 0; i < count; i++) {
            cout << "\n----------------------------";
            list[i]->getDetails();
            cout << "\nArea: " << list[i]->area();
            cout << "\nPerimeter: " << list[i]->perimeter();
            list[i]->draw();
        }
    }

    void sortByArea() {
        for (int i = 0; i < count - 1; i++) {
            for (int j = i + 1; j < count; j++) {
                if (list[i]->area() > list[j]->area()) {
                    shape* temp = list[i];
                    list[i] = list[j];
                    list[j] = temp;
                }
            }
        }
    }

    shape* largestArea() {
        if (count == 0) return NULL;

        shape* largest = list[0];
        for (int i = 1; i < count; i++) {
            if (list[i]->area() > largest->area()) {
                largest = list[i];
            }
        }
        return largest;
    }
};

int main() {
    shapemanager sm;

    circle c1("Red", "Circle-A", 5);
    rectangle r1("Blue", "Rectangle-B", 4, 6);
    triangle t1("Green", "Triangle-C", 3, 4, 5);
    pentagon p1("Yellow", "Pentagon-D", 2);

    sm.addShape(&c1);
    sm.addShape(&r1);
    sm.addShape(&t1);
    sm.addShape(&p1);

    cout << "\n=== All Shapes ===";
    sm.showAllShapes();

    sm.sortByArea();
    cout << "\n\n=== Shapes Sorted by Area ===";
    sm.showAllShapes();

    shape* biggest = sm.largestArea();
    if (biggest != NULL) {
        cout << "\n\n=== Shape With the Largest Area ===";
        biggest->getDetails();
        cout << "\nArea: " << biggest->area();
        biggest->draw();
    }

    return 0;
}
