#include <iostream>
#include <string>
using namespace std;

class Student {
private:
    string name;
    int id;
    float gpa;
    string* courses; 
    int courseCount;

public:
    // Default Constructor
    Student() {
        name = "Unknown";
        id = 0;
        gpa = 0.0;
        courseCount = 0;
        courses = nullptr;
        cout << "Default constructor called for " << name << endl;
    }

    // Parameterized Constructor
    Student(string n, int i, float g) {
        name = n;
        id = i;
        gpa = g;
        courseCount = 0;
        courses = nullptr;
        cout << "Parameterized constructor called for " << name << endl;
    }

    // Copy Constructor (Deep Copy)
    Student(const Student& other) {
        name = other.name;
        id = other.id;
        gpa = other.gpa;
        courseCount = other.courseCount;

        if (courseCount > 0) {
            courses = new string[courseCount];
            for (int i = 0; i < courseCount; i++) {
                courses[i] = other.courses[i];
            }
        } else {
            courses = nullptr;
        }

        cout << "Copy constructor called for " << name << endl;
    }

    // Destructor
    ~Student() {
        delete[] courses;
        cout << "Destructor called for " << name << endl;
    }

    // Add Course (Dynamic Resizing)
    void addCourse(const string& course) {
        string* newCourses = new string[courseCount + 1];
        for (int i = 0; i < courseCount; i++) {
            newCourses[i] = courses[i];
        }
        newCourses[courseCount] = course;
        delete[] courses;
        courses = newCourses;
        courseCount++;
    }

    // Display Function
    void display() const {
        cout << "\n----- Student Info -----" << endl;
        cout << "Name: " << name << endl;
        cout << "ID: " << id << endl;
        cout << "GPA: " << gpa << endl;
        cout << "Courses Enrolled (" << courseCount << "): ";
        if (courseCount == 0)
            cout << "None";
        else
            for (int i = 0; i < courseCount; i++)
                cout << courses[i] << (i == courseCount - 1 ? "" : ", ");
        cout << endl;
    }

    // Get GPA
    float getGPA() const {
        return gpa;
    }

    // Set GPA
    void setGPA(float newGPA) {
        gpa = newGPA;
    }
};

int main() {
    // Create Student using Default Constructor
    Student s1;
    s1.addCourse("Mathematics");
    s1.addCourse("Physics");

    // Create Student using Parameterized Constructor
    Student s2("Ali", 101, 3.8);
    s2.addCourse("Programming");
    s2.addCourse("Data Structures");

    // Display both
    s1.display();
    s2.display();


    Student s3 = s2;
    s3.display();

    s2.setGPA(3.2);
    s2.addCourse("Algorithms");

    cout << "\nAfter modifying s2:" << endl;
    s2.display();
    s3.display();  

    return 0;
}
