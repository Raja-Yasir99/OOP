#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

class BankAccount {
private:
    string accountNumber;
    string accountHolder;
    double balance;
    string* transactionHistory;
    int transactionCount;

    void addTransaction(const string& description) {
        string* newHistory = new string[transactionCount + 1];
        
        for (int i = 0; i < transactionCount; i++) {
            newHistory[i] = transactionHistory[i];
        }
        
        newHistory[transactionCount] = description;
        
        delete[] transactionHistory;
        transactionHistory = newHistory;
        transactionCount++;
    }

public:
    BankAccount() 
        : accountNumber("000000"), accountHolder("Unknown"), balance(0.0), 
          transactionHistory(nullptr), transactionCount(0) {
        cout << "Default constructor called - Account: " << accountNumber << endl;
    }

    BankAccount(const string& accNumber, const string& accHolder, double initialBalance)
        : accountNumber(accNumber), accountHolder(accHolder), balance(initialBalance),
          transactionHistory(nullptr), transactionCount(0) {
        
        if (initialBalance > 0) {
            addTransaction("Initial deposit: $" + to_string(initialBalance));
        }
        
        cout << "Parameterized constructor called - Account: " << accountNumber << endl;
    }

    BankAccount(const BankAccount& other)
        : accountNumber(other.accountNumber), accountHolder(other.accountHolder),
          balance(other.balance), transactionCount(other.transactionCount) {
        
        if (other.transactionHistory != nullptr && other.transactionCount > 0) {
            transactionHistory = new string[other.transactionCount];
            for (int i = 0; i < other.transactionCount; i++) {
                transactionHistory[i] = other.transactionHistory[i];
            }
        } else {
            transactionHistory = nullptr;
        }
        
        cout << "Copy constructor called - Account: " << accountNumber << endl;
    }

    ~BankAccount() {
        delete[] transactionHistory;
        cout << "Destructor called - Account: " << accountNumber << " destroyed" << endl;
    }

    bool deposit(double amount) {
        if (amount <= 0) {
            cout << "Error: Deposit amount must be positive." << endl;
            return false;
        }
        
        balance += amount;
        string transaction = "Deposit: $" + to_string(amount);
        addTransaction(transaction);
        
        cout << "Deposited $" << amount << " to account " << accountNumber << endl;
        return true;
    }

    bool withdraw(double amount) {
        if (amount <= 0) {
            cout << "Error: Withdrawal amount must be positive." << endl;
            return false;
        }
        
        if (amount > balance) {
            cout << "Error: Insufficient funds. Available: $" << balance << endl;
            return false;
        }
        
        balance -= amount;
        string transaction = "Withdrawal: $" + to_string(amount);
        addTransaction(transaction);
        
        cout << "Withdrew $" << amount << " from account " << accountNumber << endl;
        return true;
    }

    double getBalance() const {
        return balance;
    }

    string getAccountNumber() const {
        return accountNumber;
    }

    string getAccountHolder() const {
        return accountHolder;
    }

    void printTransactionHistory() const {
        cout << "\n=== Transaction History for Account " << accountNumber << " ===" << endl;
        cout << "Account Holder: " << accountHolder << endl;
        cout << "Current Balance: $" << fixed << setprecision(2) << balance << endl;
        cout << "Transactions (" << transactionCount << "):" << endl;
        
        if (transactionCount == 0) {
            cout << "  No transactions recorded." << endl;
        } else {
            for (int i = 0; i < transactionCount; i++) {
                cout << "  " << (i + 1) << ". " << transactionHistory[i] << endl;
            }
        }
        cout << "=====================================" << endl;
    }

    bool transferTo(BankAccount& target, double amount) {
        if (amount <= 0) {
            cout << "Error: Transfer amount must be positive." << endl;
            return false;
        }
        
        if (amount > balance) {
            cout << "Error: Insufficient funds for transfer. Available: $" << balance << endl;
            return false;
        }
        
        balance -= amount;
        target.balance += amount;
        
        string senderTransaction = "Transfer to " + target.getAccountNumber() + ": $" + to_string(amount);
        string receiverTransaction = "Transfer from " + accountNumber + ": $" + to_string(amount);
        
        addTransaction(senderTransaction);
        target.addTransaction(receiverTransaction);
        
        cout << "Transferred $" << amount << " from account " << accountNumber 
             << " to account " << target.getAccountNumber() << endl;
        return true;
    }
};

int main() {
    cout << "=== BANK ACCOUNT MANAGEMENT SYSTEM ===" << endl;
    cout << "Demonstrating Object Lifecycle and Resource Management\n" << endl;

    cout << "1. CREATING BANK ACCOUNTS" << endl;
    cout << "-------------------------" << endl;
    BankAccount account1("123456", "Alice Johnson", 1000.0);
    BankAccount account2("789012", "Bob Smith", 500.0);
    
    cout << "\nInitial Balances:" << endl;
    cout << "Account " << account1.getAccountNumber() << " (" << account1.getAccountHolder() 
         << "): $" << account1.getBalance() << endl;
    cout << "Account " << account2.getAccountNumber() << " (" << account2.getAccountHolder() 
         << "): $" << account2.getBalance() << endl;

    cout << "\n2. PERFORMING TRANSACTIONS" << endl;
    cout << "--------------------------" << endl;
    
    account1.deposit(250.0);
    account1.withdraw(100.0);
    account1.deposit(75.5);
    account1.withdraw(50.0);
    
    account2.deposit(100.0);
    account2.withdraw(25.5);
    account2.deposit(200.0);
    account2.withdraw(300.0);

    cout << "\n3. TRANSFERING FUNDS" << endl;
    cout << "--------------------" << endl;
    account1.transferTo(account2, 150.0);
    account1.transferTo(account2, 2000.0);

    cout << "\n4. TRANSACTION HISTORIES" << endl;
    cout << "-----------------------" << endl;
    account1.printTransactionHistory();
    account2.printTransactionHistory();

    cout << "\n5. DEMONSTRATING DEEP COPY" << endl;
    cout << "--------------------------" << endl;
    BankAccount accountCopy = account1;
    
    cout << "\nOriginal Account (" << account1.getAccountNumber() << ") Balance: $" 
         << account1.getBalance() << endl;
    cout << "Copied Account (" << accountCopy.getAccountNumber() << ") Balance: $" 
         << accountCopy.getBalance() << endl;

    cout << "\n6. MODIFYING ORIGINAL ACCOUNT" << endl;
    cout << "----------------------------" << endl;
    account1.deposit(100.0);
    account1.withdraw(50.0);
    
    cout << "\n7. VERIFYING INDEPENDENCE" << endl;
    cout << "-------------------------" << endl;
    cout << "After modifications to original account:" << endl;
    cout << "Original Account Balance: $" << account1.getBalance() << endl;
    cout << "Copied Account Balance: $" << accountCopy.getBalance() << endl;
    
    cout << "\nOriginal Account Transaction History:" << endl;
    account1.printTransactionHistory();
    
    cout << "\nCopied Account Transaction History (should be unchanged):" << endl;
    accountCopy.printTransactionHistory();

    cout << "\n=== PROGRAM COMPLETED SUCCESSFULLY ===" << endl;

    return 0;
}