#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

class Book {
private:
    string title;
    string author;
    string isbn;
    bool isAvailable;

public:
    Book() : title("Unknown"), author("Unknown"), isbn("0000000000"), isAvailable(true) {}

    Book(string t, string a, string i) : title(std::move(t)), author(std::move(a)), isbn(std::move(i)), isAvailable(true) {}

    Book(const Book &other) : title(other.title), author(other.author), isbn(other.isbn), isAvailable(other.isAvailable) {}
    
    ~Book() {
        cout << "Book \"" << title << "\" is being removed from memory." << endl;
    }

    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    string getISBN() const { return isbn; }
    bool getAvailability() const { return isAvailable; }

    void setTitle(string t) { title = std::move(t); }
    void setAuthor(string a) { author = std::move(a); }
    void setISBN(string i) { isbn = std::move(i); }
    void setAvailability(bool available) { isAvailable = available; }

    void display() const {
        cout << "Title: " << title << endl;
        cout << "Author: " << author << endl;
        cout << "ISBN: " << isbn << endl;
        cout << "Availability: " << (isAvailable ? "Available" : "Borrowed") << endl;
        cout << "--------------------------------" << endl;
    }
};

// ---

class Library {
private:
    string name;
    vector<Book> books;

    vector<Book>::iterator findBookIterator(const string &isbn) {
        return std::find_if(books.begin(), books.end(), 
                           [&isbn](Book& b){ return b.getISBN() == isbn; });
    }
    
    vector<Book>::const_iterator findBookIterator(const string &isbn) const {
        return std::find_if(books.begin(), books.end(), 
                           [&isbn](const Book& b){ return b.getISBN() == isbn; });
    }

public:
    Library() : name("Unknown") {}

    Library(string n) : name(std::move(n)) {}

    ~Library() {
        cout << "Library \"" << name << "\" has been closed and memory released." << endl;
    }

    void addBook(const Book &book) {
        books.push_back(book);
        cout << "Book \"" << book.getTitle() << "\" has been added to the library." << endl;
    }

    void removeBook(const string &isbn) {
        auto it = findBookIterator(isbn);

        if (it == books.end()) {
            cout << "No book found with ISBN " << isbn << endl;
            return;
        }
        
        books.erase(it);
        cout << "Book with ISBN " << isbn << " has been removed from the library." << endl;
    }

    Book* findBook(const string &isbn) {
        auto it = findBookIterator(isbn);
        if (it != books.end()) {
            return &(*it);
        }
        return nullptr;
    }
    
    void borrowBook(const string &isbn) {
        Book* b = findBook(isbn);
        if (b == nullptr) {
            cout << "No book found with ISBN " << isbn << endl;
            return;
        }
        if (b->getAvailability()) {
            b->setAvailability(false);
            cout << "You have successfully borrowed \"" << b->getTitle() << "\"." << endl;
        } else {
            cout << "Sorry, \"" << b->getTitle() << "\" is already borrowed." << endl;
        }
    }

    void returnBook(const string &isbn) {
        Book* b = findBook(isbn);
        if (b == nullptr) {
            cout << "No book found with ISBN " << isbn << endl;
            return;
        }
        if (!b->getAvailability()) {
            b->setAvailability(true);
            cout << "Book \"" << b->getTitle() << "\" has been returned successfully." << endl;
        } else {
            cout << "This book was not borrowed." << endl;
        }
    }

    void displayAllBooks() const {
        cout << endl << "Library Name: " << name << endl;
        cout << "Total Books: " << books.size() << endl;
        cout << "--------------------------------" << endl;
        for (const auto& book : books) {
            book.display();
        }
    }
};


int main() {
    Library lib("City Central Library");

    Book b1("C++ Made Easy", "Bilal", "111");
    Book b2("The Art of Coding", "Yasir", "222");
    Book b3("OOP Simplified", "Zaid", "333");
    Book b4("Mastering Algorithms", "Umer", "444");
    Book b5("Data Structures 101", "Hanzla", "555");

    lib.addBook(b1);
    lib.addBook(b2);
    lib.addBook(b3);
    lib.addBook(b4);
    lib.addBook(b5);

    cout << endl << "=== All books in the library ===" << endl;
    lib.displayAllBooks();

    lib.borrowBook("333");
    lib.borrowBook("555");

    cout << endl << "=== After borrowing some Books ===" << endl;
    lib.displayAllBooks();

    lib.returnBook("333");

    cout << endl << "=== After returning a Book ===" << endl;
    lib.displayAllBooks();

    lib.removeBook("222");

    cout << endl << "=== After removing a Book ===" << endl;
    lib.displayAllBooks();

    Library libCopy = lib; 
    cout << endl << "=== Library copy before changes ===" << endl;
    libCopy.displayAllBooks();

    lib.removeBook("111");

    cout << endl << "=== Original library after changes ===" << endl;
    lib.displayAllBooks();

    cout << endl << "=== Copied Library should remain same ===" << endl;
    libCopy.displayAllBooks();

    return 0;
}