#ifndef BOOK_H
#define BOOK_H

#include <string>
using namespace std;

class book{
	private:
		string title;
		string author;
		string isbn;
		bool available;
		
		static int totalbook;
		static int availablebook;
		static int borrowedbook;
		
		public:
			book(string t,string a,string i,bool av);
			void borrowbook();
			void returnbook();
			void displaybookinfo();
			
			static void displaylibrarystats();
			static void getavailabilityrate();
	
	
};
#endif