#include "book.h"

int main(){
	book a1("c++","shoaib ","0909",true);
	book a2("oop","ali ","0908",true);
	
	
	a1.displaybookinfo();
	a2.displaybookinfo();
	
	a1.borrowbook();
	a2.borrowbook();
	
	
    book::displaylibrarystats();
    book::getavailabilityrate();
    a1.returnbook();
    
    book::displaylibrarystats();
    book::getavailabilityrate();
	
	return 0;
}