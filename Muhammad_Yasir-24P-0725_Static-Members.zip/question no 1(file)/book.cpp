#include <iostream>
#include "book.h"
using namespace std;

int totalbooks=0;
int availablebooks=0;
int borrowedbooks=0;



book::book(string t,string a,string i,bool av){
	title=t;
	author=a;
	isbn=i;
	available=av;
	
}

void book::borrowbook(){
	if (available) {
        available = false;
        availablebooks--;
        borrowedbooks++;
        cout << title << "\n borrowed it";
    } else {
        cout << title << "\n not available ";
    }
}
	

void book::returnbook(){
if (!available) {
        available = true;
        availablebooks++;
        borrowedbooks--;
        cout << title << "\n returned it";
    } else {
        cout << title << "\n not borrow";
    }
}


void book::displaybookinfo(){
	cout<<"available book ";
	returnbook();
	borrowbook();
}

void book::displaylibrarystats(){
	cout << "\n total book " << totalbooks;
    cout << "\n available book " << availablebooks;
    cout << "\n borrow book" << borrowedbooks;
}


void book::getavailabilityrate() {
    if (totalbooks == 0)
        cout << "no book in library\n";
    else
        cout << "availabiluty rate " 
             << (availablebooks * 100.0 / totalbooks);
}

