#include <iostream>
using namespace std;

class Student {
protected:
    string fullName;
    int studentID;
    double gradePointAverage;
    string* courseList;
    int totalCourses;
    int currentCourseCount = 0;

public:
    Student(string name, int id, double gpa, int maxCourses) {
        fullName = name;
        studentID = id;
        gradePointAverage = gpa;
        totalCourses = maxCourses;
        currentCourseCount = 0;
        courseList = new string[totalCourses];
    }

    ~Student() {
        delete[] courseList;
    }

    void addCourse(string courseName) {
        if (currentCourseCount < totalCourses) {
            courseList[currentCourseCount] = courseName;
            currentCourseCount++;
            cout << "Course added successfully.\n";
        } else {
            cout << "You have reached the maximum number of courses.\n";
        }
    }

    double getGPA() {
        return gradePointAverage;
    }

    void showStudentInfo() {
        cout << "\nName: " << fullName;
        cout << "\nStudent ID: " << studentID;
        cout << "\nGPA: " << gradePointAverage;
        if (currentCourseCount == 0) {
            cout << "\nNo courses added yet.\n";
        } else {
            cout << "\nCourses Enrolled:\n";
            for (int i = 0; i < currentCourseCount; i++) {
                cout << "  " << i + 1 << ". " << courseList[i] << endl;
            }
        }
    }
};

class StudentDatabase {
protected:
    Student** studentRecords;
    int maxStudents;
    int currentStudentCount = 0;

public:
    StudentDatabase(int totalStudents) {
        maxStudents = totalStudents;
        studentRecords = new Student*[maxStudents];
    }

    ~StudentDatabase() {
        for (int i = 0; i < currentStudentCount; i++) {
            delete studentRecords[i];
        }
        delete[] studentRecords;
        cout << "\nDatabase destroyed successfully.\n";
    }

    void createStudent() {
        if (currentStudentCount < maxStudents) {
            string name;
            int id, totalCourses;
            double gpa;

            cout << "\nEnter student name: ";
            cin.ignore();
            getline(cin, name);

            cout << "Enter student ID: ";
            cin >> id;

            cout << "Enter GPA: ";
            cin >> gpa;

            cout << "Enter total number of courses: ";
            cin >> totalCourses;

            studentRecords[currentStudentCount] = new Student(name, id, gpa, totalCourses);

            for (int i = 0; i < totalCourses; i++) {
                string courseName;
                cout << "Enter course " << i + 1 << ": ";
                cin >> courseName;
                studentRecords[currentStudentCount]->addCourse(courseName);
            }

            currentStudentCount++;
            cout << "\nStudent record added successfully!\n";
        } else {
            cout << "\nMaximum student limit reached.\n";
        }
    }

    void displayAllStudents() {
        if (currentStudentCount == 0) {
            cout << "\nNo student records found.\n";
        } else {
            for (int i = 0; i < currentStudentCount; i++) {
                cout << "\n--- Student " << i + 1 << " Information ---\n";
                studentRecords[i]->showStudentInfo();
            }
        }
    }

    double calculateAverageGPA() {
        if (currentStudentCount == 0) {
            cout << "\nNo student records to calculate GPA.\n";
            return 0.0;
        } else {
            double totalGPA = 0.0;
            for (int i = 0; i < currentStudentCount; i++) {
                totalGPA += studentRecords[i]->getGPA();
            }
            return totalGPA / currentStudentCount;
        }
    }
};

int main() {
    int totalStudents;
    cout << "Enter how many students you want to add: ";
    cin >> totalStudents;

    StudentDatabase* db = new StudentDatabase(totalStudents);

    for (int i = 0; i < totalStudents; i++) {
        cout << "\n--- Enter details for Student " << i + 1 << " ---\n";
        db->createStudent();
    }

    db->displayAllStudents();
    cout << "\nAverage GPA: " << db->calculateAverageGPA() << endl;

    delete db;

    return 0;
}
