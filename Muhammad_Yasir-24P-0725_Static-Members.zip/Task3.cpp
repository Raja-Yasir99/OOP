#include <iostream>
using namespace std;

class faculty {
protected:
    string facultyName;
    int facultyID;
    string positionTitle;
    string facultyDepartment;

public:
    faculty(string name, int id, string title, string dept) {
        facultyName = name;
        facultyID = id;
        positionTitle = title;
        facultyDepartment = dept;
    }

    void showDetails() {
        cout << "\nFaculty Name: " << facultyName;
        cout << "\nEmployee ID: " << facultyID;
        cout << "\nDesignation: " << positionTitle;
        cout << "\nDepartment: " << facultyDepartment << endl;
    }

    string getName() {
        return facultyName;
    }
};

class course {
protected:
    string courseTitle;
    string courseCode;
    int creditHours;
    faculty* courseInstructor;

public:
    course(string title, string code, int credits) {
        courseTitle = title;
        courseCode = code;
        creditHours = credits;
        courseInstructor = nullptr;
    }

    void assignInstructor(faculty* f) {
        courseInstructor = f;
    }

    void showCourseInfo() {
        cout << "\nCourse Title: " << courseTitle;
        cout << "\nCourse Code: " << courseCode;
        cout << "\nCredit Hours: " << creditHours;
        if (courseInstructor != nullptr) {
            cout << "\nInstructor: " << courseInstructor->getName() << endl;
        } else {
            cout << "\nInstructor not yet assigned.\n";
        }
    }

    int getCredits() {
        return creditHours;
    }
};

class department {
protected:
    string deptName;
    faculty** facultyList;
    course** courseList;
    int maxFaculty;
    int maxCourses;
    int facultyCount;
    int courseCount;

public:
    department(string name, int facultyLimit, int courseLimit) {
        deptName = name;
        maxFaculty = facultyLimit;
        maxCourses = courseLimit;
        facultyCount = 0;
        courseCount = 0;
        facultyList = new faculty*[maxFaculty];
        courseList = new course*[maxCourses];
    }

    ~department() {
        for (int i = 0; i < facultyCount; i++) {
            delete facultyList[i];
        }
        for (int i = 0; i < courseCount; i++) {
            delete courseList[i];
        }
        delete[] facultyList;
        delete[] courseList;
        cout << "\nDepartment " << deptName << " destroyed successfully.\n";
    }

    void addFaculty(string name, int id, string title) {
        if (facultyCount >= maxFaculty) {
            cout << "\nCannot add more faculty to " << deptName << ". Limit reached.";
            return;
        }
        facultyList[facultyCount++] = new faculty(name, id, title, deptName);
        cout << "\nFaculty member added successfully.";
    }

    void addCourse(string title, string code, int credits) {
        if (courseCount >= maxCourses) {
            cout << "\nCannot add more courses to " << deptName << ". Limit reached.";
            return;
        }
        courseList[courseCount++] = new course(title, code, credits);
        cout << "\nCourse added successfully.";
    }

    void assignInstructor(int courseIdx, int facultyIdx) {
        if (courseIdx >= 0 && courseIdx < courseCount && facultyIdx >= 0 && facultyIdx < facultyCount) {
            courseList[courseIdx]->assignInstructor(facultyList[facultyIdx]);
            cout << "\nInstructor assigned successfully.";
        } else {
            cout << "\nInvalid indexes provided for assignment.";
        }
    }

    int getTotalCredits() {
        int total = 0;
        for (int i = 0; i < courseCount; i++) {
            total += courseList[i]->getCredits();
        }
        return total;
    }

    void showDepartmentInfo() {
        cout << "\n\n--- Department: " << deptName << " ---\n";
        cout << "\nFaculty Members:\n";
        for (int i = 0; i < facultyCount; i++) {
            facultyList[i]->showDetails();
        }

        cout << "\nCourses Offered:\n";
        for (int i = 0; i < courseCount; i++) {
            courseList[i]->showCourseInfo();
        }

        cout << "\nTotal Credit Hours in Department: " << getTotalCredits() << endl;
    }

    int getFacultyCount() {
        return facultyCount;
    }

    int getCourseCount() {
        return courseCount;
    }
};

class university {
protected:
    string uniName;
    department** departmentList;
    int maxDepartments;
    int currentDeptCount;

public:
    university(string name, int deptLimit) {
        uniName = name;
        maxDepartments = deptLimit;
        currentDeptCount = 0;
        departmentList = new department*[maxDepartments];
    }

    ~university() {
        for (int i = 0; i < currentDeptCount; i++) {
            delete departmentList[i];
        }
        delete[] departmentList;
        cout << "\nUniversity destroyed successfully.\n";
    }

    void addDepartment(string name, int facultyLimit, int courseLimit) {
        if (currentDeptCount >= maxDepartments) {
            cout << "\nCannot add more departments. Limit reached.";
            return;
        }
        departmentList[currentDeptCount++] = new department(name, facultyLimit, courseLimit);
        cout << "\nDepartment added successfully.";
    }

    void showUniversityInfo() {
        cout << "\n\n===== " << uniName << " Information =====\n";
        for (int i = 0; i < currentDeptCount; i++) {
            departmentList[i]->showDepartmentInfo();
        }
        cout << "\nTotal Faculty in University: " << getTotalFaculty();
        cout << "\nTotal Courses in University: " << getTotalCourses() << endl;
    }

    int getTotalFaculty() {
        int total = 0;
        for (int i = 0; i < currentDeptCount; i++) {
            total += departmentList[i]->getFacultyCount();
        }
        return total;
    }

    int getTotalCourses() {
        int total = 0;
        for (int i = 0; i < currentDeptCount; i++) {
            total += departmentList[i]->getCourseCount();
        }
        return total;
    }
};

int main() {
    university uni("National Tech University", 2);

    uni.addDepartment("Computer Science", 2, 2);
    uni.addDepartment("Mathematics", 1, 2);

    cout << "\nSetting up departments manually...";

    department* csDept = new department("Computer Science", 2, 2);
    csDept->addFaculty("Dr. Ali", 101, "Professor");
    csDept->addFaculty("Mr. Shoaib", 102, "Lecturer");
    csDept->addCourse("OOP", "CS101", 3);
    csDept->addCourse("Data Structures", "CS102", 4);
    csDept->assignInstructor(0, 0);
    csDept->assignInstructor(1, 1);

    department* mathDept = new department("Mathematics", 1, 2);
    mathDept->addFaculty("Mr. Hamza", 201, "Assistant Professor");
    mathDept->addCourse("Calculus", "MTH101", 3);
    mathDept->addCourse("Algebra", "MTH102", 3);
    mathDept->assignInstructor(0, 0);
    mathDept->assignInstructor(1, 0);

    csDept->showDepartmentInfo();
    mathDept->showDepartmentInfo();

    cout << "\n\n--- University Overview ---";
    uni.showUniversityInfo();

    delete csDept;
    delete mathDept;

    return 0;
}
