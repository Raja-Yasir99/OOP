#include <iostream>
#include <iomanip>
using namespace std;

//Function to convertt temp in fahrenhiet
void convertTemperature(double* celsius, double* fahrenheit) {
    *fahrenheit = (*celsius * 9.0 / 5.0) + 32.0;
}

int main() {
    const int days = 7;
    string week[days] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    double celsius[days], fahrenheit[days];

    // Input temp in celsius
    cout << "Enter temperatures in Celsius for 7 days:\n";
    for (int i = 0; i < days; i++) {
        cout << week[i] << ": ";
        cin >> celsius[i];
        convertTemperature(&celsius[i], &fahrenheit[i]);
    }

    cout << "\n=========== Weekly Temperature Report ===========\n";
    cout << left << setw(13) << "Day"
         << right << setw(13) << "Celsius"
         << setw(13) << "Fahrenheit" << endl;
    cout << "-------------------------------------------------\n";

    double hottest = celsius[0], coldest = celsius[0];
    string hotDay = week[0], coldDay = week[0];

    for (int i = 0; i < days; i++) {
        cout << left << setw(12) << week[i]
             << right << setw(12) << fixed << setprecision(2) << celsius[i]
             << setw(15) << fixed << setprecision(2) << fahrenheit[i] << endl;

        // check hottest and coldest
        if (celsius[i] > hottest) {
            hottest = celsius[i];
            hotDay = week[i];
        }
        if (celsius[i] < coldest) {
            coldest = celsius[i];
            coldDay = week[i];
        }
    }

    // Display hottest and coldest day
    cout << "-------------------------------------------------\n";
    cout << "Hottest Day: " << hotDay << " (" << hottest << " Degree C)\n";
    cout << "Coldest Day: " << coldDay << " (" << coldest << " Degree C)\n";

    return 0;
}
