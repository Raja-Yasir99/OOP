#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

const int N = 3;       
const int W = 6;          

//Function declarations
void inputMatrix(int M[N][N], const string& name);
void displayMatrix(const int M[N][N], const string& title);
void addMatrices(const int A[N][N], const int B[N][N], int C[N][N]);
void transposeMatrix(const int A[N][N], int T[N][N]);
void multiplyMatrices(const int A[N][N], const int B[N][N], int C[N][N], bool showSteps);


void inputMatrix(int M[N][N], const string& name) {
    cout << "Enter elements of " << name << " (row-wise, 9 integers):\n";
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            cout << name << "[" << i << "][" << j << "]: ";
            cin >> M[i][j];
        }
    }
}

void displayMatrix(const int M[N][N], const string& title) {
    cout << "\n" << title << ":\n";
    cout << "+---------------------+\n";
    for (int i = 0; i < N; ++i) {
        cout << "|";
        for (int j = 0; j < N; ++j) {
            cout << setw(W) << M[i][j];
        }
        cout << "  |\n";
    }
    cout << "+---------------------+\n";
}

void addMatrices(const int A[N][N], const int B[N][N], int C[N][N]) {
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            C[i][j] = A[i][j] + B[i][j];
}

void transposeMatrix(const int A[N][N], int T[N][N]) {
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            T[j][i] = A[i][j];
}

void multiplyMatrices(const int A[N][N], const int B[N][N], int C[N][N], bool showSteps) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            int sum = 0;
            if (showSteps) {
                cout << "C[" << i << "][" << j << "] = ";
                // Show the dot product expression
                for (int k = 0; k < N; ++k) {
                    cout << "A[" << i << "][" << k << "]*B[" << k << "][" << j << "]";
                    if (k != N - 1) cout << " + ";
                }
                cout << " = ";
            }
            for (int k = 0; k < N; ++k) {
                if (showSteps) {
                    cout << A[i][k] << "*" << B[k][j];
                    if (k != N - 1) cout << " + ";
                }
                sum += A[i][k] * B[k][j];
            }
            C[i][j] = sum;
            if (showSteps) cout << " = " << sum << "\n";
        }
    }
}

// ---- Main (Menu) ----
int main() {
    int A[N][N] = {0}, B[N][N] = {0}, R[N][N] = {0}, T[N][N] = {0};
    bool hasA = false, hasB = false;

    int choice;
    do {
        cout << "\n===== Matrix Operations Calculator (3x3) =====\n";
        cout << "1. Input Matrix A\n";
        cout << "2. Input Matrix B\n";
        cout << "3. Add matrices (A + B)\n";
        cout << "4. Multiply matrices (A × B)\n";
        cout << "5. Transpose matrix A\n";
        cout << "6. Display matrices (A and B)\n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                inputMatrix(A, "A"); hasA = true;
                break;

            case 2:
                inputMatrix(B, "B"); hasB = true;
                break;

            case 3:
                if (!hasA || !hasB) {
                    cout << "Please input both A and B first.\n";
                    break;
                }
                addMatrices(A, B, R);
                displayMatrix(A, "Matrix A");
                displayMatrix(B, "Matrix B");
                displayMatrix(R, "A + B");
                break;

            case 4:
                if (!hasA || !hasB) {
                    cout << "Please input both A and B first.\n";
                    break;
                }
                cout << "\nStep-by-step multiplication (row • column):\n";
                multiplyMatrices(A, B, R, true);
                displayMatrix(A, "Matrix A");
                displayMatrix(B, "Matrix B");
                displayMatrix(R, "A × B");
                break;

            case 5:
                if (!hasA) {
                    cout << "Please input Matrix A first.\n";
                    break;
                }
                transposeMatrix(A, T);
                displayMatrix(A, "Matrix A");
                displayMatrix(T, "Transpose of A");
                break;

            case 6:
                if (hasA) displayMatrix(A, "Matrix A");
                else cout << "Matrix A not entered yet.\n";
                if (hasB) displayMatrix(B, "Matrix B");
                else cout << "Matrix B not entered yet.\n";
                break;

            case 7:
                cout << "Goodbye!\n";
                break;

            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 7);

    return 0;
}
