#include <iostream>
#include <iomanip>
using namespace std;

// Function to reverse array
void reverseArray(int arr[], int size) {
    int start = 0, end = size - 1;
    while (start < end) {
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        start++;
        end--;
    }
}
// Function to sort array using Bubble Sort
void sortArray(int arr[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
// Function to search for an element
int searchElement(int arr[], int size, int key) {
    for (int i = 0; i < size; i++) {
        if (arr[i] == key)
            return i; 
    }
    return -1; 
}
// Function to remove duplicates
int removeDuplicates(int arr[], int size) {
    if (size == 0 || size == 1)
        return size;

    int temp[size];
    int j = 0;

    for (int i = 0; i < size - 1; i++) {
        if (arr[i] != arr[i + 1]) {
            temp[j++] = arr[i];
        }
    }
    temp[j++] = arr[size - 1];

    for (int i = 0; i < j; i++) {
        arr[i] = temp[i];
    }

    return j; //new size of arr
}
// Function to display array
void displayArray(int arr[], int size) {
    cout << "Array Elements: ";
    for (int i = 0; i < size; i++) {
        cout << setw(4) << arr[i];
    }
    cout << endl;
}

int main() {
    int size;
    cout << "Enter size of array: ";
    cin >> size;

    int arr[100]; 
    cout << "Enter " << size << " elements: ";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }

    int choice, key;
    do {
        cout << "\n===== Array Manipulation Toolkit =====\n";
        cout << "1. Reverse Array\n";
        cout << "2. Sort Array\n";
        cout << "3. Search Element\n";
        cout << "4. Remove Duplicates\n";
        cout << "5. Display Array\n";
        cout << "6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                reverseArray(arr, size);
                cout << "Array reversed.\n";
                break;
            case 2:
                sortArray(arr, size);
                cout << "Array sorted.\n";
                break;
            case 3:
                cout << "Enter element to search: ";
                cin >> key;
                {
                    int pos = searchElement(arr, size, key);
                    if (pos != -1)
                        cout << "Element found at position: " << pos + 1 << endl;
                    else
                        cout << "Element not found.\n";
                }
                break;
            case 4:
                sortArray(arr, size); 
                size = removeDuplicates(arr, size);
                cout << "Duplicates removed.\n";
                break;
            case 5:
                displayArray(arr, size);
                break;
            case 6:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    }
	 while (choice != 6);

    return 0;
}
