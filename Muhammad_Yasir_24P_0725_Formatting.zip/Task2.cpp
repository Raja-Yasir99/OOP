#include <iostream>
#include <iomanip>
using namespace std;

const int MAX_STUDENTS = 10;
const int SUBJECTS = 5;

void calculateStudentStats(int marks[], int subjects, int* total, double* average) {
    *total = 0;
    for (int i = 0; i < subjects; i++) {
        *total += marks[i];
    }
    *average = static_cast<double>(*total) / subjects;
}

void calculateSubjectAverage(int allMarks[][SUBJECTS], int students, double subjectAvg[]) {
    for (int j = 0; j < SUBJECTS; j++) {
        int sum = 0;
        for (int i = 0; i < students; i++) {
            sum += allMarks[i][j];
        }
        subjectAvg[j] = static_cast<double>(sum) / students;
    }
}

void displayReport(int allMarks[][SUBJECTS], int studentCount, int totals[], double averages[], double subjectAvgs[]) {
    cout << "\n\nGRADE REPORT\n";
    cout << "================================================================================\n";
    cout << "Student | Subject 1 | Subject 2 | Subject 3 | Subject 4 | Subject 5 | Total Marks | Average Marks |\n";
    cout << "================================================================================\n";
    
    for (int i = 0; i < studentCount; i++) {
        cout << setw(7) << i+1 << " |";
        for (int j = 0; j < SUBJECTS; j++) {
            cout << setw(5) << allMarks[i][j] << " |";
        }
        cout << setw(6) << totals[i] << " |";
        cout << setw(8) << fixed << setprecision(2) << averages[i] << " |\n";
    }
    
    cout << "================================================================================\n";
    cout << "Subject Average|";
    for (int j = 0; j < SUBJECTS; j++) {
        cout << setw(5) << fixed << setprecision(1) << subjectAvgs[j] << " |";
    }
    cout << "       |        |\n";
    cout << "================================================================================\n";
    
    // Find top performer
    int topIndex = 0;
    for (int i = 1; i < studentCount; i++) {
        if (totals[i] > totals[topIndex]) {
            topIndex = i;
        }
    }
    cout << "Top Performer: Student " << topIndex + 1 << " with total marks: " << totals[topIndex] << "\n";
}

int main() {
    int marks[MAX_STUDENTS][SUBJECTS];
    int studentCount;
    
    cout << "NUCES GRADE CALCULATOR PRO\n";
    cout << "====================\n";
    
    cout << "Enter number of students (max " << MAX_STUDENTS << "): ";
    cin >> studentCount;
    
    if (studentCount > MAX_STUDENTS || studentCount <= 0) {
        cout << "Invalid number of students!\n";
        return 1;
    }
    
    // Input marks for each student
    for (int i = 0; i < studentCount; i++) {
        cout << "\nEnter marks for Student " << i + 1 << " (5 subjects):\n";
        for (int j = 0; j < SUBJECTS; j++) {
            cout << "Subject " << j + 1 << ": ";
            cin >> marks[i][j];
        }
    }
    
    // Calculate student stats
    int totals[MAX_STUDENTS];
    double averages[MAX_STUDENTS];
    
    for (int i = 0; i < studentCount; i++) {
        calculateStudentStats(marks[i], SUBJECTS, &totals[i], &averages[i]);
    }
    
    // Calculate subject avgs
    
    double subjectAvgs[SUBJECTS];
    calculateSubjectAverage(marks, studentCount, subjectAvgs);
    
    // Display report
    displayReport(marks, studentCount, totals, averages, subjectAvgs);
    
    return 0;
}