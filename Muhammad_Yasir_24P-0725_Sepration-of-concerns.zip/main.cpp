#include <iostream>
#include "BankAccount.h"
using namespace std;

int main() {
    BankAccount a1("Yasir", 240725, 5000.0);
    a1.show();
    a1.deposit(1500);
    a1.withdraw(2000);
    a1.show();
    return 0;
}
