#include <iostream>
#include "BankAccount.h"
using namespace std;

BankAccount::BankAccount() {
    holderName = "Not Set";
    accountNo = 0;
    balance = 0.0;
}

BankAccount::BankAccount(string name, int number, double amount) {
    holderName = name;
    accountNo = number;
    balance = amount;
}

void BankAccount::deposit(double money) {
    if (money > 0) {
        balance += money;
        cout << "Successfully deposited: $" << money << endl;
    } else {
        cout << "Invalid deposit amount!" << endl;
    }
}

void BankAccount::withdraw(double money) {
    if (money > 0 && money <= balance) {
        balance -= money;
        cout << "Withdrawal of $" << money << " completed." << endl;
    } else {
        cout << "Insufficient balance or invalid amount!" << endl;
    }
}

void BankAccount::display() const {
    cout << "\n--- Account Details ---" << endl;
    cout << "Name: " << holderName << endl;
    cout << "Account No: " << accountNo << endl;
    cout << "Balance: $" << balance << endl;
}
