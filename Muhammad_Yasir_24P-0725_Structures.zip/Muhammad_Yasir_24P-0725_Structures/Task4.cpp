#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//VEHICAL DETAILS
struct Vehicle {
    string manufacturer;
    string model;
    int year;
    double mileage;
    double price;
    bool is_new;
};

//DISPLAY VEHICAL DETAILS
void showVehicle(const Vehicle& v) {
    cout << left << setw(10) << v.manufacturer
         << setw(12) << v.model
         << setw(8)  << v.year
         << setw(10) << fixed << setprecision(0) << v.mileage
         << "$" << setw(10) << fixed << setprecision(2) << v.price
         << (v.is_new ? "New" : "Used") << endl;
}

void sortByPrice(Vehicle cars[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (cars[j].price > cars[j + 1].price) {
                swap(cars[j], cars[j + 1]);
            }
        }
    }
}

int main() {
    const int total_cars = 10;
    Vehicle inventory[total_cars];
    cout << "----------------------------------- RYJ SHOWROOM --------------------------------\n";
    for (int i = 0; i < total_cars; i++) {
        cout << "Enter details of Vehicle " << i + 1 << ":" << endl;

        cout << "Manufacturer: ";
        getline(cin, inventory[i].manufacturer);

        cout << "Model: ";
        getline(cin, inventory[i].model);

        cout << "Year: ";
        cin >> inventory[i].year;

        cout << "Mileage: ";
        cin >> inventory[i].mileage;

        cout << "Price: ";
        cin >> inventory[i].price;

        cout << "Is New (YES = 1, NO = 0): ";
        cin >> inventory[i].is_new;
        cin.ignore();

        cout << endl;
    }

    cout << endl << "VEHICLE INVENTORY" << endl;
    cout << "=================" << endl;
    cout << left << setw(10) << "Manufacturer"
         << setw(12) << "Model"
         << setw(8)  << "Year"
         << setw(10) << "Mileage"
         << setw(11) << "Price"
         << "Status" << endl;
    cout << string(60, '-') << endl;
    for (int i = 0; i < total_cars; i++) {
        showVehicle(inventory[i]);
    }

    string search_term;
    cout << endl << "Search by Make or Model: ";
    getline(cin, search_term);

    cout << endl << "SEARCH RESULTS" << endl;
    cout << "==============" << endl;
    bool found = false;
    for (int i = 0; i < total_cars; i++) {
        if (inventory[i].manufacturer == search_term || inventory[i].model == search_term) {
            showVehicle(inventory[i]);
            found = true;
        }
    }
    if (!found) cout << "No matching vehicles found." << endl;

    sortByPrice(inventory, total_cars);

    cout << endl << "VEHICLES SORTED BY PRICE" << endl;
    cout << "========================" << endl;
    for (int i = 0; i < total_cars; i++) {
        showVehicle(inventory[i]);
    }

    double totalValue = 0;
    for (int i = 0; i < total_cars; i++) {
        totalValue += inventory[i].price;
    }
    cout << endl << "Total Inventory Value: $" << fixed << setprecision(2) << totalValue << endl;

    double min_price, max_price;
    cout << endl << "Enter Price Range (min max): ";
    cin >> min_price >> max_price;

    cout << endl << "VEHICLES IN PRICE RANGE $" << min_price << " - $" << max_price << endl;
    cout << "================================================" << endl;
    bool in_range = false;
    for (int i = 0; i < total_cars; i++) {
        if (inventory[i].price >= min_price && inventory[i].price <= max_price) {
            showVehicle(inventory[i]);
            in_range = true;
        }
    }
    if (!in_range) cout << "No vehicles found in this range." << endl;

    return 0;
}
