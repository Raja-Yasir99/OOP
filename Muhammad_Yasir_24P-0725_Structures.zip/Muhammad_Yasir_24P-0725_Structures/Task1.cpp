#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct book {
    string title;
    string author;
    string ISBN;
    int pages;
    double price;
    bool isAvailable;
};

void DisplayBook(const book& b, int index) {
    cout << "Book " << index + 1 << ": \"" << b.title << "\" by " << b.author << endl;
    cout << "ISBN: " << b.ISBN
         << ", Pages: " << b.pages
         << ", Price: $" << fixed << setprecision(4) << b.price << endl;
    cout << "Status: " << (b.isAvailable ? "Available" : "Out of Stock, Available soon") << endl << endl;
}

int main() {
    const int total_books= 3;
    book library[total_books];

    for (int i = 0; i < total_books; i++) {
        cout << "Enter Details for Book " << i + 1 << ":" << endl;

        cout << "Title: ";
        getline(cin, library[i].title);

        cout << "Author: ";
        getline(cin, library[i].author);

        cout << "ISBN: ";
        getline(cin, library[i].ISBN);

        cout << "Pages: ";
        cin >> library[i].pages;

        cout << "Price: ";
        cin >> library[i].price;

        cout << "Is Available (1 = Yes, 0 = No): ";
        cin >> library[i].isAvailable;

        cin.ignore(); 
        cout << endl;
    }

    cout << endl << "FAST NUCES Peshawar LIBRARY MANAGEMENT SYSTEM" << endl;
    cout << "============================================" << endl;

    for (int i = 0; i < total_books; i++) {
        DisplayBook(library[i], i);
    }

    int expensive_index = 0;
    for (int i = 1; i < total_books; i++) {
        if (library[i].price > library[expensive_index].price) {
            expensive_index = i;
        }
    }

    cout << "Most Expensive Book: \"" << library[expensive_index].title
         << "\" - $" << fixed << setprecision(4)
         << library[expensive_index].price << endl;

    return 0;
}
