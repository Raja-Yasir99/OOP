#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//student struct

struct Student {
    string full_name;
    int student_ID;
    double test_scores[3];
    double average_score;
    char letter_grade;
};
//grade function
char calculateGrade(double avg) {
    if (avg >= 90) 
	return 'A';
    if (avg >= 80) 
	return 'B';
    if (avg >= 70) 
	return 'C';
    if (avg >= 60) 
	return 'D';
    return 'F';
}

int main() {
    const int num_students = 5;
    Student students[num_students];

    for (int student_index = 0; student_index < num_students; student_index++) {
        cout << "Enter details for Student " << student_index + 1 << ":" << endl;

        cout << "Name: ";
        getline(cin, students[student_index].full_name);

        cout << "ID: ";
        cin >> students[student_index].student_ID;

        double scores_sum = 0;
        for (int test_index = 0; test_index < 3; test_index++) {
            cout << "Test " << test_index + 1 << ": ";
            cin >> students[student_index].test_scores[test_index];
            scores_sum += students[student_index].test_scores[test_index];
        }

        students[student_index].average_score = scores_sum / 3.0;
        students[student_index].letter_grade = calculateGrade(students[student_index].average_score);

        cin.ignore();
        cout << endl;
    }

    cout << endl << "STUDENT GRADE REPORT" << endl;
    cout << "====================" << endl;
    cout << left << setw(20) << "Name"
         << setw(10) << "ID"
         << setw(12) << "Average"
         << setw(8)  << "Grade" << endl;
    cout << string(50, '-') << endl;

    for (int student_index = 0; student_index < num_students; student_index++) {
        cout << left << setw(20) << students[student_index].full_name
             << setw(10) << students[student_index].student_ID
             << setw(12) << fixed << setprecision(2) << students[student_index].average_score
             << setw(8)  << students[student_index].letter_grade << endl;
    }

    double highest_avg = students[0].average_score;
    double lowest_avg = students[0].average_score;
    double totalAvgSum = 0;

    int gradeCount_A = 0;
	int gradeCount_B = 0;
	int gradeCount_C = 0;
	int gradeCount_D = 0;
	int gradeCount_F = 0;

    for (int student_index = 0; student_index < num_students; student_index++) {
        if (students[student_index].average_score > highest_avg) highest_avg = students[student_index].average_score;
        if (students[student_index].average_score < lowest_avg) lowest_avg = students[student_index].average_score;
        totalAvgSum += students[student_index].average_score;

        switch (students[student_index].letter_grade) {
            case 'A': gradeCount_A++; 
			break;
			
            case 'B': gradeCount_B++; 
			break;
			
            case 'C': gradeCount_C++; 
			break;
			
            case 'D': gradeCount_D++; 
			break;
			
            case 'F': gradeCount_F++; 
			break;
        }
    }

    double class_avg = totalAvgSum / num_students;

    cout << endl << "CLASS STATISTICS" << endl;
    cout << "================" << endl;
    cout << "Highest Average : " << fixed << setprecision(2) << highest_avg << endl;
    cout << "Lowest Average  : " << fixed << setprecision(2) << lowest_avg << endl;
    cout << "Class Average   : " << fixed << setprecision(2) << class_avg << endl;

    cout << endl << "GRADE DISTRIBUTION" << endl;
    cout << "==================" << endl;
    cout << "A: " << gradeCount_A << endl;
    cout << "B: " << gradeCount_B << endl;
    cout << "C: " << gradeCount_C << endl;
    cout << "D: " << gradeCount_D << endl;
    cout << "F: " << gradeCount_F << endl;

    return 0;
}
