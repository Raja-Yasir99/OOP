#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct Date {
    int day, month, year;
};

struct Address {
    string street;
	string city;
	string state; 
	string zip_code;
};

struct Patient {
    string name;
    int id;
    Address address;
    Date admission;
    Date discharge;
    string diagnosis;
    double bill_amount;
};

Patient* addPatient(Patient* list, int &count) {
    int new_count = count + 1;
    Patient* temp = new Patient[new_count];
    for (int i = 0; i < count; i++) {
        temp[i] = list[i];
    }

    cout << "Adding new patient in the system... " << endl;
    cout << "Name: ";
    cin.ignore(); 
    getline(cin, temp[count].name);

    temp[count].id = new_count; 

    cout << "Street: ";
    getline(cin, temp[count].address.street);
    cout << "City: ";
    getline(cin, temp[count].address.city);
    cout << "State: ";
    getline(cin, temp[count].address.state);
    cout << "Zip Code: ";
    getline(cin, temp[count].address.zip_code);

    cout << "Admission Day Month Year: ";
    cin >> temp[count].admission.day >> temp[count].admission.month >> temp[count].admission.year;

    temp[count].discharge = temp[count].admission; 

    cin.ignore();
    cout << "Diagnosis: ";
    getline(cin, temp[count].diagnosis);

    temp[count].bill_amount = 0.0;

    count = new_count;
    return temp;
}

int findPatientIndex(Patient* list, int count, int id) {
    for (int i = 0; i < count; i++) {
        if (list[i].id == id) return i;
    }
    return -1;
}

int days_stay(const Patient& p) {
    return p.discharge.day - p.admission.day;
}

void generate_bill(Patient* list, int count, int id) {
    int idx = findPatientIndex(list, count, id);
    if (idx == -1) {
        cout << "Patient not found." << endl;
        return;
    }

    int days = days_stay(list[idx]);
    double rate = 0.0;

    if (list[idx].diagnosis == "surgery") rate = 1000;
    else if (list[idx].diagnosis == "general") rate = 500;
    else if (list[idx].diagnosis == "maternity") rate = 700;
    else rate = 300;

    double base = rate * days;
    double bill = base - (base * 0.10); 

    list[idx].bill_amount = bill;

    cout << "Bill generated for " << list[idx].name << " : $" << fixed << setprecision(2) << list[idx].bill_amount << endl;
}

void showPatient(const Patient& p) {
    cout << left << setw(20) << p.name
         << " ID:" << setw(5) << p.id
         << " Admit:" << p.admission.day << "/" << p.admission.month << "/" << p.admission.year
         << " Disch:" << p.discharge.day << "/" << p.discharge.month << "/" << p.discharge.year
         << " Diagnosis:" << p.diagnosis
         << " Bill:$" << fixed << setprecision(2) << p.bill_amount << endl;
}

void displayPatientsByMonth(Patient* list, int count, int month) {
    bool any = false;
    for (int i = 0; i < count; i++) {
        if (list[i].admission.month == month) {
            showPatient(list[i]);
            any = true;
        }
    }
    if (!any) cout << "No patients admitted in month " << month << "." << endl;
}

int main() {
    Patient* patients = nullptr;
    int patientCount = 0;
    
    cout << "---------------------------- PESHAWAR MEDICAL COMPLEX --------------------------------------";
    while (true) {
        cout << " \n1) Add patient ";
		cout << " \n2) Search by ID ";
		cout << " \n3) Days of stay "; 
		cout << " \n4) Generate Bill "; 
		cout << " \n5) Show by Month "; 
		cout << " \n6) Show All ";  
		cout << " \n0) Exit\n";
        cout << " Choose: ";
        int option;
        cin >> option;

        if (option == 1) {
            patients = addPatient(patients, patientCount);
        }
        else if (option == 2) {
            cout << "Enter ID to search: ";
            int id; cin >> id;
            int idx = findPatientIndex(patients, patientCount, id);
            if (idx == -1) cout << "Not found." << endl;
            else showPatient(patients[idx]);
        }
        else if (option == 3) {
            cout << "Enter ID to get days of stay: ";
            int id; cin >> id;
            int idx = findPatientIndex(patients, patientCount, id);
            if (idx == -1) cout << "Not found." << endl;
            else {
                cout << "Days of stay (simple calc): " << days_stay(patients[idx]) << endl;
            }
        }
        else if (option == 4) {
            cout << "Enter ID to generate bill: ";
            int id; cin >> id;
            generate_bill(patients, patientCount, id);
        }
        else if (option == 5) {
            cout << "Enter month number (1-12): ";
            int m; cin >> m;
            displayPatientsByMonth(patients, patientCount, m);
        }
        else if (option == 6) {
            for (int i = 0; i < patientCount; i++) showPatient(patients[i]);
        }
        else {
            cout << "Invalid option." << endl;
        }
    }

    return 0;
}
