#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

// addressof employee
struct Address {
    string street;
    string city;
    string state;
    string zipCode;
};
//employee details
struct employee {
    string name;
    int id;
    Address address;
    double hourly_rate;
    double hours_worked;
    double gross_pay;
    double net_pay;
};

int main() {
    const int num_of_employees = 3;
    employee employee [num_of_employees];

    for (int i = 0; i < num_of_employees ; i++) {
        cout << "Enter details for Employee " << i + 1 << ":" << endl;

        cout << "Name: ";
        getline(cin, employee[i].name);

        cout << "ID: ";
        cin >> employee[i].id;
        cin.ignore();

        cout << "Street: ";
        getline(cin, employee[i].address.street);

        cout << "City: ";
        getline(cin, employee[i].address.city);

        cout << "State: ";
        getline(cin, employee[i].address.state);

        cout << "Zip Code: ";
        getline(cin, employee[i].address.zipCode);

        cout << "Hourly Rate: ";
        cin >> employee[i].hourly_rate;

        cout << "Hours Worked: ";
        cin >> employee[i].hours_worked;
        cin.ignore();

        employee[i].gross_pay = employee[i].hourly_rate * employee[i].hours_worked;
        employee[i].net_pay = employee[i].gross_pay - (employee[i].gross_pay * 0.20);

        cout << endl;
    }

    cout << endl << "NUCES MONTHLY PAYROLL REPORT" << endl;
    cout << "==============================================" << endl;
    cout << left << setw(17) << "Name"
         << setw(12) << "ID"
         << setw(12) << "Gross Pay"
         << setw(12) << "Net Pay" << endl;
    cout << string(50, '-') << endl;

    for (int i = 0; i < num_of_employees ; i++) {
        cout << left << setw(15) << employee[i].name
             << setw(10) << employee[i].id
             << "$" << setw(11) << fixed << setprecision(2) << employee[i].gross_pay
             << "$" << setw(11) << fixed << setprecision(2) << employee[i].net_pay << endl;
    }

    int highest_index = 0;
    for (int i = 1; i < num_of_employees ; i++) {
        if (employee[i].net_pay > employee[highest_index].net_pay) {
            highest_index = i;
        }
    }

    cout << endl << "NUCES EMPLOYEE WITH HIGHEST NET PAY" << endl;
    cout << "===================================================" << endl;
    cout << employee[highest_index].name 
         << " (ID: " << employee[highest_index].id << ")"
         << " - Net Pay: $" << fixed << setprecision(2) 
         << employee[highest_index].net_pay << endl;

    return 0;
}
